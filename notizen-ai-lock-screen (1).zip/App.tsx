import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { INITIAL_NOTIFICATIONS, MOCK_INCOMING } from './constants';
import { AppNotification, NotificationCategory, SummaryResponse } from './types';
import { getSmartSummary, organizeNotifications, generateGroupSummaries } from './services/geminiService';
import { NotificationCard } from './components/NotificationCard';
import { SettingsSheet } from './components/SettingsSheet';
import { Sparkles, LayoutList, Trash2, Smartphone, Plus, RefreshCw, Lock, Unlock, Bell, Settings as SettingsIcon } from 'lucide-react';

export default function App() {
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [summaryData, setSummaryData] = useState<SummaryResponse | null>(null);
  const [appGroupSummaries, setAppGroupSummaries] = useState<Record<string, string>>({}); // Stores app-specific summaries
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [viewMode, setViewMode] = useState<'raw' | 'smart'>('raw');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isLocked, setIsLocked] = useState(true);
  
  // Customization State
  const [showSettings, setShowSettings] = useState(false);
  const [customCategories, setCustomCategories] = useState<string[]>(Object.values(NotificationCategory));
  const [appRules, setAppRules] = useState<Record<string, string>>({});

  // Clock Ticker
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleDismiss = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const handleIncomingNotification = () => {
    const random = MOCK_INCOMING[Math.floor(Math.random() * MOCK_INCOMING.length)];
    const newNotif = { ...random, id: Date.now().toString(), timestamp: new Date() };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleSmartSort = async () => {
    if (isProcessing) return;
    setIsProcessing(true);
    setAppGroupSummaries({}); // Reset old summaries
    
    // 1. Get Categories from AI
    const categorized = await organizeNotifications(notifications, customCategories);
    
    // 2. Update State with Categories AND Apply Overrides
    const updatedNotifications = notifications.map(n => {
        if (appRules[n.appName] && customCategories.includes(appRules[n.appName])) {
             return { ...n, category: appRules[n.appName], isPriority: n.isPriority };
        }
        const update = categorized.find(c => c.id === n.id);
        if (update) {
            const validCategory = customCategories.includes(update.category) 
                ? update.category 
                : NotificationCategory.Uncategorized;
            return { ...n, category: validCategory, isPriority: update.isPriority };
        }
        return n;
    });
    
    setNotifications(updatedNotifications);

    // 3. Identify App Groups (Apps with > 1 notification in the same category)
    // We group by App Name here to prepare for summarization
    const appGroups: Record<string, AppNotification[]> = {};
    updatedNotifications.forEach(n => {
        if (!appGroups[n.appName]) appGroups[n.appName] = [];
        appGroups[n.appName].push(n);
    });

    const groupsToSummarize = Object.entries(appGroups)
        .filter(([_, items]) => items.length > 1)
        .map(([appName, items]) => ({ appName, notifications: items }));

    // 4. Parallel Requests: Global Summary & Group Summaries
    const [summary, groupSummariesList] = await Promise.all([
        getSmartSummary(updatedNotifications),
        generateGroupSummaries(groupsToSummarize)
    ]);

    // Store group summaries
    const summariesMap: Record<string, string> = {};
    groupSummariesList.forEach(item => {
        summariesMap[item.appName] = item.summary;
    });
    setAppGroupSummaries(summariesMap);

    setSummaryData(summary);
    setViewMode('smart');
    setIsProcessing(false);
  };

  const handleClearAll = () => {
    setNotifications([]);
    setSummaryData(null);
    setViewMode('raw');
  };

  const resetState = () => {
      setNotifications(INITIAL_NOTIFICATIONS);
      setSummaryData(null);
      setViewMode('raw');
  };

  const addCategory = (cat: string) => {
      setCustomCategories(prev => [...prev, cat]);
  };

  const removeCategory = (cat: string) => {
      setCustomCategories(prev => prev.filter(c => c !== cat));
      const newRules = { ...appRules };
      Object.keys(newRules).forEach(key => {
          if (newRules[key] === cat) delete newRules[key];
      });
      setAppRules(newRules);
  };

  const updateRule = (appName: string, category: string) => {
      setAppRules(prev => {
          const next = { ...prev };
          if (!category) delete next[appName];
          else next[appName] = category;
          return next;
      });
  };

  const uniqueApps = useMemo(() => {
     const apps = new Set(notifications.map(n => n.appName));
     MOCK_INCOMING.forEach(n => apps.add(n.appName));
     return Array.from(apps).sort();
  }, [notifications]);

  // Group notifications for Smart View logic
  const groupedNotifications = React.useMemo(() => {
    if (viewMode === 'raw') return { all: notifications };
    
    const groups: Record<string, AppNotification[]> = {};
    customCategories.forEach(cat => { groups[cat] = []; });
    if (!groups[NotificationCategory.Uncategorized]) groups[NotificationCategory.Uncategorized] = [];

    notifications.forEach(n => {
      const cat = n.category && customCategories.includes(n.category) 
        ? n.category 
        : NotificationCategory.Uncategorized;
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(n);
    });

    return groups;
  }, [notifications, viewMode, customCategories]);

  // Helper to render a category's content with App Grouping
  const renderCategoryContent = (categoryItems: AppNotification[], isCompactCategory: boolean) => {
      if (!categoryItems || categoryItems.length === 0) return null;

      // Group by App within this category
      const appBuckets: Record<string, AppNotification[]> = {};
      categoryItems.forEach(n => {
          if (!appBuckets[n.appName]) appBuckets[n.appName] = [];
          appBuckets[n.appName].push(n);
      });

      return Object.values(appBuckets).map(items => {
          const firstItem = items[0];
          // If multiple items, render grouped card
          if (items.length > 1) {
              return (
                  <NotificationCard 
                      key={`group-${firstItem.appName}-${firstItem.id}`}
                      notification={firstItem} // Uses icon/app name from first item
                      onDismiss={handleDismiss} 
                      compact={isCompactCategory}
                      isGroup={true}
                      groupCount={items.length}
                      groupSummary={appGroupSummaries[firstItem.appName]}
                      subNotifications={items}
                  />
              );
          }
          // Single item
          return (
              <NotificationCard 
                key={firstItem.id} 
                notification={firstItem} 
                onDismiss={handleDismiss} 
                compact={isCompactCategory}
              />
          );
      });
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 p-4">
      
      {/* Phone Simulator Frame */}
      <div className="relative w-full max-w-[400px] h-[850px] bg-black rounded-[3rem] shadow-2xl border-8 border-gray-800 overflow-hidden ring-4 ring-gray-900/50">
        
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-7 bg-black rounded-b-2xl z-50"></div>
        
        {/* Wallpaper */}
        <div 
            className="absolute inset-0 bg-cover bg-center z-0 transition-all duration-700"
            style={{ 
                backgroundImage: 'url("https://picsum.photos/400/850?grayscale&blur=2")',
                filter: isLocked ? 'brightness(0.7)' : 'brightness(1)'
            }}
        />

        {/* Lock Screen UI */}
        <div className="absolute inset-0 z-10 flex flex-col p-6 pt-16 text-white">
          
          {/* Header / Clock */}
          <div className="flex flex-col items-center mb-8 relative">
             <div className="absolute right-0 top-0">
                 <button 
                    onClick={() => setShowSettings(true)}
                    className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
                 >
                     <SettingsIcon size={18} className="text-white/80" />
                 </button>
             </div>

             {isLocked && <Lock size={20} className="mb-2 opacity-50"/>}
             {!isLocked && <Unlock size={20} className="mb-2 opacity-50"/>}
            <h1 className="text-7xl font-thin tracking-tighter">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
            </h1>
            <p className="text-lg font-medium opacity-80 mt-1">
              {currentTime.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}
            </p>
          </div>

          {/* AI Summary Widget */}
          <AnimatePresence>
            {viewMode === 'smart' && summaryData && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, height: 0 }}
                animate={{ opacity: 1, scale: 1, height: 'auto' }}
                exit={{ opacity: 0, scale: 0.9, height: 0 }}
                className="bg-white/10 backdrop-blur-xl rounded-2xl p-4 mb-6 border border-white/20 shadow-xl"
              >
                <div className="flex items-center gap-2 mb-2 text-purple-300">
                  <Sparkles size={16} className="animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-widest">Gemini Summary</span>
                </div>
                <p className="text-sm font-medium leading-relaxed mb-3 text-white/90">
                  {summaryData.summary}
                </p>
                {summaryData.actionItems.length > 0 && (
                  <div className="space-y-1">
                    {summaryData.actionItems.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-white/70 bg-black/20 p-2 rounded-lg">
                        <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                        {item}
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Notification List */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar pb-24 mask-image-b">
            <AnimatePresence mode='popLayout'>
              
              {/* RAW MODE */}
              {viewMode === 'raw' && notifications.map((notif) => (
                <NotificationCard 
                  key={notif.id} 
                  notification={notif} 
                  onDismiss={handleDismiss} 
                />
              ))}

              {/* SMART MODE */}
              {viewMode === 'smart' && (
                <div className="space-y-6">
                    {/* Render Categories in Order: Important First, then custom, then others */}
                    {customCategories.sort((a,b) => {
                        // Priority sort helper
                        if (a === NotificationCategory.Important) return -1;
                        if (b === NotificationCategory.Important) return 1;
                        return 0;
                    }).map(cat => {
                        const items = groupedNotifications[cat];
                        if (!items || items.length === 0) return null;
                        
                        const isCompact = cat === NotificationCategory.Promotional || cat === NotificationCategory.System;
                        
                        let colorClass = 'text-gray-400';
                        if (cat === NotificationCategory.Important) colorClass = 'text-red-300';
                        if (cat === NotificationCategory.Social) colorClass = 'text-blue-300';
                        if (!Object.values(NotificationCategory).includes(cat as any)) colorClass = 'text-purple-300';

                        return (
                            <div key={cat}>
                                <h4 className={`text-xs font-bold uppercase tracking-wider mb-2 ml-2 ${colorClass}`}>
                                    {cat}
                                </h4>
                                {renderCategoryContent(items, isCompact)}
                            </div>
                        );
                    })}
                </div>
              )}

              {notifications.length === 0 && (
                <motion.div 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center h-40 text-white/30"
                >
                    <Bell size={48} className="mb-2" />
                    <p>No new notifications</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bottom Action Bar */}
          <div className="absolute bottom-6 left-6 right-6 z-20">
            <div className="flex items-center justify-between gap-4">
               <button 
                  onClick={handleClearAll}
                  className="p-3 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md transition-colors text-white border border-white/10"
                >
                   <Trash2 size={20} />
               </button>

               <button 
                onClick={viewMode === 'raw' ? handleSmartSort : () => setViewMode('raw')}
                disabled={isProcessing || notifications.length === 0}
                className={`flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-full font-semibold transition-all shadow-lg active:scale-95
                    ${viewMode === 'raw' 
                        ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:shadow-purple-500/30' 
                        : 'bg-white/10 text-white hover:bg-white/20 border border-white/20'
                    }
                    ${isProcessing ? 'opacity-70 cursor-wait' : ''}
                `}
               >
                 {isProcessing ? (
                     <>
                        <RefreshCw size={18} className="animate-spin" />
                        <span>Thinking...</span>
                     </>
                 ) : viewMode === 'raw' ? (
                     <>
                        <Sparkles size={18} />
                        <span>Summarize & Sort</span>
                     </>
                 ) : (
                     <>
                        <LayoutList size={18} />
                        <span>Show All</span>
                     </>
                 )}
               </button>

                <button 
                    onClick={() => setIsLocked(!isLocked)}
                    className="p-3 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md transition-colors text-white border border-white/10"
                >
                    {isLocked ? <Unlock size={20} /> : <Lock size={20} />}
                </button>
            </div>
            
            <div className="w-32 h-1 bg-white/30 mx-auto mt-6 rounded-full" />
          </div>

          {/* Settings Overlay */}
          <SettingsSheet 
            isOpen={showSettings} 
            onClose={() => setShowSettings(false)}
            categories={customCategories}
            onAddCategory={addCategory}
            onRemoveCategory={removeCategory}
            appRules={appRules}
            onUpdateRule={updateRule}
            uniqueApps={uniqueApps}
          />

        </div>
      </div>

      {/* Development Controls */}
      <div className="fixed top-4 right-4 flex flex-col gap-2">
         <div className="bg-gray-800 p-4 rounded-xl border border-gray-700 shadow-xl max-w-xs">
            <h3 className="text-white font-bold mb-2 flex items-center gap-2">
                <Smartphone size={16} /> Dev Controls
            </h3>
            <p className="text-xs text-gray-400 mb-4">
                Simulate incoming data for the prototype.
            </p>
            <div className="space-y-2">
                <button 
                    onClick={handleIncomingNotification}
                    className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-xs py-2 px-3 rounded-lg transition-colors"
                >
                    <Plus size={14} /> Send Mock Notification
                </button>
                <button 
                    onClick={resetState}
                    className="w-full flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 text-white text-xs py-2 px-3 rounded-lg transition-colors"
                >
                    <RefreshCw size={14} /> Reset Demo
                </button>
            </div>
         </div>
      </div>

    </div>
  );
}
