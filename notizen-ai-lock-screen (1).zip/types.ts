export enum NotificationCategory {
  Uncategorized = 'Uncategorized',
  Important = 'Important',
  Social = 'Social',
  Promotional = 'Promotional',
  System = 'System',
}

export interface AppNotification {
  id: string;
  appName: string;
  title: string;
  content: string;
  timestamp: Date;
  icon: string; // Emoji or simple string identifier
  category: string; // Changed from Enum to string to support custom categories
  isPriority: boolean;
}

export interface SummaryResponse {
  summary: string;
  actionItems: string[];
}

export interface CategorizedNotificationItem {
  id: string;
  category: string;
  isPriority: boolean;
}
