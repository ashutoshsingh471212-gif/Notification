import React, { useState } from 'react';
import { motion, PanInfo, AnimatePresence } from 'framer-motion';
import { AppNotification, NotificationCategory } from '../types';
import { MessageCircle, Mail, Car, Settings, Instagram, Slack, BookOpen, Calendar, DollarSign, Bell, ChevronDown, Layers } from 'lucide-react';

interface NotificationCardProps {
  notification: AppNotification;
  onDismiss: (id: string) => void;
  compact?: boolean;
  // New props for grouping
  isGroup?: boolean;
  groupCount?: number;
  groupSummary?: string;
  subNotifications?: AppNotification[];
}

const getIcon = (iconName: string) => {
  switch (iconName) {
    case 'message-circle': return <MessageCircle size={16} />;
    case 'mail': return <Mail size={16} />;
    case 'car': return <Car size={16} />;
    case 'settings': return <Settings size={16} />;
    case 'instagram': return <Instagram size={16} />;
    case 'slack': return <Slack size={16} />;
    case 'book-open': return <BookOpen size={16} />;
    case 'calendar': return <Calendar size={16} />;
    case 'dollar-sign': return <DollarSign size={16} />;
    default: return <Bell size={16} />;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case NotificationCategory.Important: return 'bg-red-500/20 border-red-500/30';
    case NotificationCategory.Social: return 'bg-blue-500/20 border-blue-500/30';
    case NotificationCategory.Promotional: return 'bg-yellow-500/20 border-yellow-500/30';
    case NotificationCategory.System: return 'bg-gray-500/20 border-gray-500/30';
    case NotificationCategory.Uncategorized: return 'bg-white/10 border-white/10';
    default: 
      // Fallback for custom user categories
      return 'bg-purple-500/20 border-purple-500/30';
  }
};

export const NotificationCard: React.FC<NotificationCardProps> = ({ 
    notification, 
    onDismiss, 
    compact, 
    isGroup, 
    groupCount, 
    groupSummary,
    subNotifications 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (info.offset.x > 100 || info.offset.x < -100) {
      if (isGroup && subNotifications) {
          // Dismiss all
          subNotifications.forEach(n => onDismiss(n.id));
      } else {
          onDismiss(notification.id);
      }
    }
  };

  const toggleExpand = (e: React.MouseEvent) => {
      e.stopPropagation();
      setIsExpanded(!isExpanded);
  };

  return (
    <motion.div
      layout
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, height: 0, marginBottom: 0 }}
      whileDrag={{ scale: 1.02, zIndex: 10 }}
      onClick={isGroup ? toggleExpand : undefined}
      className={`relative w-full mb-3 rounded-2xl backdrop-blur-xl border border-white/20 overflow-hidden shadow-lg select-none touch-pan-y transition-colors
         ${getCategoryColor(notification.category)}
         ${isGroup ? 'cursor-pointer' : ''}
      `}
    >
      <div className={`p-4 ${compact ? 'py-3' : ''}`}>
        <div className="flex items-center gap-2 mb-1 opacity-80">
          <div className="bg-white/20 p-1 rounded-full relative">
            {getIcon(notification.icon)}
            {/* Stack indicator for groups */}
            {isGroup && (
                <div className="absolute -top-1 -right-1 bg-white text-black text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {groupCount}
                </div>
            )}
          </div>
          <span className="text-xs font-medium text-white uppercase tracking-wider">{notification.appName}</span>
          
          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs text-white/50">{notification.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            {isGroup && (
                <motion.div animate={{ rotate: isExpanded ? 180 : 0 }}>
                    <ChevronDown size={14} className="text-white/50" />
                </motion.div>
            )}
          </div>
        </div>
        
        {/* Main Content */}
        {isGroup ? (
             <div className="pr-2">
                <h3 className="text-sm font-semibold text-white/90 italic flex items-center gap-1.5">
                    <Layers size={12} className="text-white/60" />
                    {groupSummary || `${groupCount} notifications`}
                </h3>
             </div>
        ) : (
            <>
                <h3 className="text-sm font-semibold text-white mb-0.5">{notification.title}</h3>
                {!compact && (
                    <p className="text-sm text-white/80 leading-snug line-clamp-2">{notification.content}</p>
                )}
            </>
        )}
      </div>

      {/* Expanded List for Groups */}
      <AnimatePresence>
          {isGroup && isExpanded && subNotifications && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="bg-black/20 border-t border-white/10"
              >
                  {subNotifications.map((sub, idx) => (
                      <div key={sub.id} className={`p-3 border-white/5 ${idx !== subNotifications.length - 1 ? 'border-b' : ''}`}>
                           <div className="flex justify-between items-start mb-0.5">
                               <h4 className="text-xs font-bold text-white">{sub.title}</h4>
                               <button 
                                  onClick={(e) => { e.stopPropagation(); onDismiss(sub.id); }}
                                  className="text-[10px] text-white/40 hover:text-white"
                               >
                                   Dismiss
                               </button>
                           </div>
                           <p className="text-xs text-white/70 leading-relaxed">{sub.content}</p>
                      </div>
                  ))}
              </motion.div>
          )}
      </AnimatePresence>
    </motion.div>
  );
};
