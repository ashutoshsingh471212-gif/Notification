import { GoogleGenAI, Type } from "@google/genai";
import { AppNotification, NotificationCategory, SummaryResponse, CategorizedNotificationItem } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-3-flash-preview";

export const getSmartSummary = async (notifications: AppNotification[]): Promise<SummaryResponse> => {
  if (notifications.length === 0) return { summary: "No notifications.", actionItems: [] };

  const prompt = `
    Analyze the following list of notifications.
    1. Provide a concise, friendly summary of the *important* things happening (max 2 sentences).
    2. Extract up to 3 short "action items" if applicable (e.g., "Reply to Mom", "Check PR").
    Ignore promotional spam or minor social interactions in the main summary unless urgent.
    
    Notifications:
    ${JSON.stringify(notifications.map(n => ({ app: n.appName, title: n.title, content: n.content })))}
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            actionItems: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
          },
          required: ["summary", "actionItems"]
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as SummaryResponse;

  } catch (error) {
    console.error("Error generating summary:", error);
    return { summary: "Could not generate summary at this time.", actionItems: [] };
  }
};

export const organizeNotifications = async (notifications: AppNotification[], availableCategories: string[]): Promise<CategorizedNotificationItem[]> => {
  if (notifications.length === 0) return [];

  // Use default categories if none provided, though the app should always provide some.
  const categoriesToUse = availableCategories.length > 0 ? availableCategories : Object.values(NotificationCategory);

  const prompt = `
    Classify the following notifications into one of these exact categories: ${categoriesToUse.join(', ')}.
    Mark 'isPriority' as true if it seems urgent, personal (like family), or work-critical.
    
    Return a JSON array where each object contains the notification 'id', 'category', and 'isPriority'.

    Notifications:
    ${JSON.stringify(notifications.map(n => ({ id: n.id, app: n.appName, title: n.title, content: n.content })))}
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              category: { 
                type: Type.STRING, 
                enum: categoriesToUse 
              },
              isPriority: { type: Type.BOOLEAN },
            },
            required: ["id", "category", "isPriority"]
          },
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as CategorizedNotificationItem[];

  } catch (error) {
    console.error("Error organizing notifications:", error);
    // Fallback: Return everything as uncategorized/low priority if AI fails
    return notifications.map(n => ({ id: n.id, category: NotificationCategory.Uncategorized, isPriority: false }));
  }
};

export const generateGroupSummaries = async (groups: { appName: string; notifications: AppNotification[] }[]): Promise<{ appName: string; summary: string }[]> => {
  if (groups.length === 0) return [];

  const prompt = `
    You are an intelligent notification assistant.
    For each group of notifications from a specific app, write a *very short*, single-sentence summary (max 12 words).
    The summary should capture the essence of the group (e.g. "3 messages from Mom and Dave about dinner" or "5 missed calls").
    
    Input Data:
    ${JSON.stringify(groups.map(g => ({ 
        appName: g.appName, 
        messages: g.notifications.map(n => n.title + ": " + n.content) 
    })))}
    
    Return a JSON Array of objects with 'appName' and 'summary'.
  `;

  try {
      const response = await ai.models.generateContent({
          model: MODEL_NAME,
          contents: prompt,
          config: {
              responseMimeType: "application/json",
              responseSchema: {
                  type: Type.ARRAY,
                  items: {
                      type: Type.OBJECT,
                      properties: {
                          appName: { type: Type.STRING },
                          summary: { type: Type.STRING }
                      },
                      required: ["appName", "summary"]
                  }
              }
          }
      });
      
      const text = response.text;
      if (!text) return [];
      return JSON.parse(text);

  } catch (error) {
      console.error("Error generating group summaries:", error);
      return [];
  }
};
