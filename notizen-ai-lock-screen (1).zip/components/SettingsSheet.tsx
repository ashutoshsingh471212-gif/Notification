import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, ChevronDown, Check } from 'lucide-react';

interface SettingsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  categories: string[];
  onAddCategory: (category: string) => void;
  onRemoveCategory: (category: string) => void;
  appRules: Record<string, string>;
  onUpdateRule: (appName: string, category: string) => void;
  uniqueApps: string[];
}

export const SettingsSheet: React.FC<SettingsSheetProps> = ({
  isOpen,
  onClose,
  categories,
  onAddCategory,
  onRemoveCategory,
  appRules,
  onUpdateRule,
  uniqueApps,
}) => {
  const [newCategory, setNewCategory] = useState('');

  const handleAdd = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      onAddCategory(newCategory.trim());
      setNewCategory('');
    }
  };

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: isOpen ? '0%' : '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 300 }}
      className="absolute bottom-0 left-0 right-0 h-[80%] bg-gray-900/95 backdrop-blur-xl rounded-t-[2.5rem] border-t border-white/10 shadow-2xl z-50 overflow-hidden flex flex-col"
    >
      {/* Handle Bar */}
      <div className="w-full flex justify-center pt-4 pb-2" onClick={onClose}>
        <div className="w-12 h-1.5 bg-white/20 rounded-full" />
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 no-scrollbar">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Customize</h2>
          <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20">
            <X size={20} className="text-white" />
          </button>
        </div>

        {/* Section 1: Categories */}
        <section className="mb-8">
          <h3 className="text-sm font-bold text-purple-300 uppercase tracking-widest mb-4">Categories</h3>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {categories.map(cat => (
              <div key={cat} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/10 border border-white/10 text-white text-sm">
                <span>{cat}</span>
                {/* Prevent deleting core categories if desired, or allow all. Allowing all for flexibility. */}
                <button 
                    onClick={() => onRemoveCategory(cat)}
                    className="opacity-50 hover:opacity-100 p-0.5"
                >
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              placeholder="New Category (e.g., Gaming)"
              className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50"
              onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
            />
            <button 
                onClick={handleAdd}
                className="bg-purple-600 hover:bg-purple-500 text-white p-3 rounded-xl transition-colors"
            >
                <Plus size={20} />
            </button>
          </div>
        </section>

        {/* Section 2: App Rules */}
        <section className="mb-12">
            <h3 className="text-sm font-bold text-blue-300 uppercase tracking-widest mb-4">App Rules</h3>
            <p className="text-xs text-white/50 mb-4">Force specific apps into categories, bypassing AI sorting.</p>
            
            <div className="space-y-3">
                {uniqueApps.length === 0 && (
                    <div className="text-center py-4 text-white/30 text-sm">No apps found yet.</div>
                )}
                {uniqueApps.map(app => (
                    <div key={app} className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/5">
                        <div className="flex items-center gap-3">
                            {/* App Name */}
                            <span className="font-medium text-white">{app}</span>
                            {appRules[app] && (
                                <span className="text-[10px] bg-green-500/20 text-green-300 px-1.5 py-0.5 rounded">Active</span>
                            )}
                        </div>
                        
                        <div className="relative">
                           <select
                              value={appRules[app] || ''}
                              onChange={(e) => onUpdateRule(app, e.target.value)}
                              className="appearance-none bg-black/40 text-white text-sm py-1.5 pl-3 pr-8 rounded-lg border border-white/10 focus:outline-none focus:border-blue-500/50"
                           >
                              <option value="">Auto (AI)</option>
                              {categories.map(cat => (
                                  <option key={cat} value={cat}>{cat}</option>
                              ))}
                           </select>
                           <ChevronDown size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none" />
                        </div>
                    </div>
                ))}
            </div>
        </section>
      </div>
    </motion.div>
  );
};
